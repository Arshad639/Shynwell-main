-- SHYNWELL: Row Level Security template. REVIEW AND TEST ON A COPY FIRST.
-- Assumes: admins(user_id uuid), and tables products, inventory, about_blocks,
-- site_settings, contact_messages, customers, billing. Adjust names if yours differ.

create or replace function public.is_admin() returns boolean
language sql security definer set search_path = public stable as
$$ select exists (select 1 from public.admins where user_id = auth.uid()) $$;

alter table public.admins            enable row level security;
alter table public.products          enable row level security;
alter table public.inventory         enable row level security;
alter table public.about_blocks      enable row level security;
alter table public.site_settings     enable row level security;
alter table public.contact_messages  enable row level security;
alter table public.customers         enable row level security;
alter table public.billing           enable row level security;

-- admins: a signed-in user may only read their own row (needed for the admin check). No client writes.
drop policy if exists admins_self_read on public.admins;
create policy admins_self_read on public.admins for select to authenticated using (user_id = auth.uid());

-- public catalogue + site content: everyone reads, only admins write
do $$ declare t text; begin
  foreach t in array array['products','inventory','about_blocks','site_settings'] loop
    execute format('drop policy if exists %I on public.%I', t||'_read', t);
    execute format('drop policy if exists %I on public.%I', t||'_admin_write', t);
    execute format('create policy %I on public.%I for select to anon, authenticated using (true)', t||'_read', t);
    execute format('create policy %I on public.%I for all to authenticated using (public.is_admin()) with check (public.is_admin())', t||'_admin_write', t);
  end loop; end $$;

-- contact form: anyone may INSERT (length-limited); only admins may read or delete
drop policy if exists contact_insert on public.contact_messages;
create policy contact_insert on public.contact_messages for insert to anon, authenticated
  with check (char_length(name) between 2 and 120 and char_length(email) between 5 and 200 and char_length(message) between 5 and 4000);
drop policy if exists contact_admin_read on public.contact_messages;
create policy contact_admin_read on public.contact_messages for select to authenticated using (public.is_admin());
drop policy if exists contact_admin_delete on public.contact_messages;
create policy contact_admin_delete on public.contact_messages for delete to authenticated using (public.is_admin());

-- billing: admins only
drop policy if exists billing_admin on public.billing;
create policy billing_admin on public.billing for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- customers: admins only here. If customers must read/update their own row, add a policy such as
--   create policy customers_self on public.customers for all to authenticated using (id = auth.uid()) with check (id = auth.uid());
-- (use your real key column).
drop policy if exists customers_admin on public.customers;
create policy customers_admin on public.customers for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- storage bucket "site-banners": public read, admin write
drop policy if exists banners_read on storage.objects;
create policy banners_read on storage.objects for select to anon, authenticated using (bucket_id = 'site-banners');
drop policy if exists banners_admin_write on storage.objects;
create policy banners_admin_write on storage.objects for all to authenticated
  using (bucket_id = 'site-banners' and public.is_admin()) with check (bucket_id = 'site-banners' and public.is_admin());

-- DB-level spam throttle: max 5 contact messages per email address per 10 minutes
create or replace function public.contact_throttle() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if (select count(*) from public.contact_messages where lower(email) = lower(new.email) and created_at > now() - interval '10 minutes') >= 5 then
    raise exception 'Too many messages. Please try again later.' using errcode = 'P0001';
  end if;
  return new;
end $$;
drop trigger if exists contact_throttle_trg on public.contact_messages;
create trigger contact_throttle_trg before insert on public.contact_messages for each row execute function public.contact_throttle();
-- (requires a created_at timestamptz column on contact_messages; add it if missing)

-- remove default broad grants from anonymous users on sensitive tables
revoke all on public.admins, public.billing, public.customers from anon;
